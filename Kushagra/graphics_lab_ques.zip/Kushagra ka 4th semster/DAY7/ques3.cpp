#include <GL/glut.h>
#include <math.h>

float angle = 45.0;

float cube[8][3] = {
    {-1, -1, -1},
    { 1, -1, -1},
    { 1,  1, -1},
    {-1,  1, -1},
    {-1, -1,  1},
    { 1, -1,  1},
    { 1,  1,  1},
    {-1,  1,  1}
};

float rCube[8][3];

void rotateX()
{
    float rad = angle * 3.14159 / 180.0;
    for(int i = 0; i < 8; i++)
    {
        float x = cube[i][0];
        float y = cube[i][1];
        float z = cube[i][2];

        rCube[i][0] = x;
        rCube[i][1] = y * cos(rad) - z * sin(rad);
        rCube[i][2] = y * sin(rad) + z * cos(rad);
    }
}

void drawCube(float v[8][3])
{
    glBegin(GL_LINES);

    glVertex3fv(v[0]); glVertex3fv(v[1]);
    glVertex3fv(v[1]); glVertex3fv(v[2]);
    glVertex3fv(v[2]); glVertex3fv(v[3]);
    glVertex3fv(v[3]); glVertex3fv(v[0]);

    glVertex3fv(v[4]); glVertex3fv(v[5]);
    glVertex3fv(v[5]); glVertex3fv(v[6]);
    glVertex3fv(v[6]); glVertex3fv(v[7]);
    glVertex3fv(v[7]); glVertex3fv(v[4]);

    glVertex3fv(v[0]); glVertex3fv(v[4]);
    glVertex3fv(v[1]); glVertex3fv(v[5]);
    glVertex3fv(v[2]); glVertex3fv(v[6]);
    glVertex3fv(v[3]); glVertex3fv(v[7]);

    glEnd();
}

void display()
{
    glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
    glLoadIdentity();

    glTranslatef(0, 0, -8);

    glColor3f(1, 0, 0);
    drawCube(cube);

    glColor3f(0, 1, 0);
    drawCube(rCube);

    glutSwapBuffers();
}

void init()
{
    glEnable(GL_DEPTH_TEST);
    glClearColor(0, 0, 0, 1);
    rotateX();
}

void reshape(int w, int h)
{
    glViewport(0, 0, w, h);

    glMatrixMode(GL_PROJECTION);
    glLoadIdentity();

    float aspect = (float)w / h;

    if (w <= h)
        glFrustum(-1, 1, -1/aspect, 1/aspect, 1, 100);
    else
        glFrustum(-1*aspect, 1*aspect, -1, 1, 1, 100);

    glMatrixMode(GL_MODELVIEW);
}

int main(int argc, char** argv)
{
    glutInit(&argc, argv);
    glutInitDisplayMode(GLUT_DOUBLE | GLUT_RGB | GLUT_DEPTH);
    glutInitWindowSize(800, 600);
    glutCreateWindow("3D Rotation about X-axis");

    init();

    glutDisplayFunc(display);
    glutReshapeFunc(reshape);

    glutMainLoop();
    return 0;
}
