#include <GL/glut.h>

// -------- Scaling Factors --------
float sx = 1.5;
float sy = 2.0;
float sz = 1.5;

// -------- Function to Draw Wireframe Pyramid --------
void drawWirePyramid()
{
    // Draw edges using lines

    glBegin(GL_LINES);

    // Apex
    float ax = 0.0, ay = 1.0, az = 0.0;

    // Base vertices
    float v1[3] = {-1.0, -1.0,  1.0};
    float v2[3] = { 1.0, -1.0,  1.0};
    float v3[3] = { 1.0, -1.0, -1.0};
    float v4[3] = {-1.0, -1.0, -1.0};

    // -------- Side Edges --------
    glVertex3f(ax, ay, az); glVertex3fv(v1);
    glVertex3f(ax, ay, az); glVertex3fv(v2);
    glVertex3f(ax, ay, az); glVertex3fv(v3);
    glVertex3f(ax, ay, az); glVertex3fv(v4);

    // -------- Base Edges --------
    glVertex3fv(v1); glVertex3fv(v2);
    glVertex3fv(v2); glVertex3fv(v3);
    glVertex3fv(v3); glVertex3fv(v4);
    glVertex3fv(v4); glVertex3fv(v1);

    glEnd();
}

// -------- Display Function --------
void display()
{
    glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
    glLoadIdentity();

    // Camera
    gluLookAt(6, 5, 10,  0, 0, 0,  0, 1, 0);

    // -------- Original Pyramid --------
    glColor3f(1.0, 0.0, 0.0); // Red
    glPushMatrix();
    glTranslatef(-2.5, 0.0, 0.0);
    drawWirePyramid();
    glPopMatrix();

    // -------- Scaled Pyramid --------
    glColor3f(0.0, 1.0, 0.0); // Green
    glPushMatrix();
    glTranslatef(2.5, 0.0, 0.0);
    glScalef(sx, sy, sz); // Scaling
    drawWirePyramid();
    glPopMatrix();

    glutSwapBuffers();
}

// -------- Initialization --------
void init()
{
    glClearColor(0.0, 0.0, 0.0, 1.0);
    glEnable(GL_DEPTH_TEST);

    // Optional: increase line thickness
    glLineWidth(2.0);
}

// -------- Reshape --------
void reshape(int w, int h)
{
    if (h == 0) h = 1;

    float aspect = (float)w / h;

    glViewport(0, 0, w, h);

    glMatrixMode(GL_PROJECTION);
    glLoadIdentity();
    gluPerspective(60.0, aspect, 1.0, 50.0);

    glMatrixMode(GL_MODELVIEW);
}

// -------- Main --------
int main(int argc, char** argv)
{
    glutInit(&argc, argv);
    glutInitDisplayMode(GLUT_DOUBLE | GLUT_RGB | GLUT_DEPTH);

    glutInitWindowSize(800, 600);
    glutCreateWindow("Wireframe Pyramid Scaling");

    init();

    glutDisplayFunc(display);
    glutReshapeFunc(reshape);

    glutMainLoop();
    return 0;
}
