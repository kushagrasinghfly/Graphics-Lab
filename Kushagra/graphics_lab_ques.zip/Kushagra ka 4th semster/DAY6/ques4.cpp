#include <GL/glut.h>
#include <bits/stdc++.h>
using namespace std;


void home(int xc, int yc){
	int x1 = 0; int y1 = 0;
	int x2 = 0; int y2 = 9;
	int x3 = 6; int y3 = 9;
	int x4 = 6; int y4 = 0;
	
	int x5 = 0; int y5 = 0;
	int x6 = 2; int y6 = 0;
	int x7 = 1; int y7 = 1;
	glBegin(GL_LINE_LOOP);
    	glVertex2f(x1, y1);
    	glVertex2f(x2, y2);
    	glVertex2f(x3, y3);
    	glVertex2f(x4, y4);
    	glEnd();
    	
    
    	glBegin(GL_LINE_LOOP);
    	glVertex2f(x5, y5);
    	glVertex2f(x6, y6);
    	glVertex2f(x7, y7);
    	glEnd();
	
	glColor3f(1.0, 0.0, 1.0);
	x1 += 5;
	x2 += 5;
	x3 += 5;
	x4 += 5;
	
	glBegin(GL_LINE_LOOP);
    	glVertex2f(x1, y1);
    	glVertex2f(x2, y2);
    	glVertex2f(x3, y3);
    	glVertex2f(x4, y4);
    	glEnd();
	
	x5 *= 3; y5 *= 3;
	x6 *= 3; y6 *= 3;
	x7 *= 3; y7 *= 3;
	
	x5 += 5;
	x6 += 5;
	x7 += 5;
	
	y5 += 9;
	y6 += 9;
	y7 += 9;
	
	glBegin(GL_LINE_LOOP);
    	glVertex2f(x5, y5);
    	glVertex2f(x6, y6);
    	glVertex2f(x7, y7);
    	glEnd();
	
    	

}


void display()
{
    glClear(GL_COLOR_BUFFER_BIT);
    glColor3f(1.0, 1.0, 1.0);

    home(0,0);

    glFlush();
}


void init()
{
    glClearColor(0.0, 0.0, 0.0, 0.0);
    glMatrixMode(GL_PROJECTION);
    gluOrtho2D(-15,15, -15, 15);  
}

int main(int argc, char** argv)
{

    glutInit(&argc, argv);
    glutInitDisplayMode(GLUT_SINGLE | GLUT_RGB);
    glutInitWindowSize(600, 600);
    glutInitWindowPosition(100, 100);
    glutCreateWindow("HOUSEMAKING");

    init();
    glutDisplayFunc(display);
    glutMainLoop();

    return 0;
}

