#include <GL/glut.h>
#include <cmath>

void display() {
    glClear(GL_COLOR_BUFFER_BIT);

    // Original line (black)
    glColor3f(0, 0, 0);
    glLineWidth(2.0);

    float x1 = 0, y1 = 0;
    float x2 = 0, y2 = 5;

    glBegin(GL_LINES);
        glVertex2f(x1, y1);
        glVertex2f(x2, y2);
    glEnd();

    // 🔹 Transformation values
    float tx = 3;   // translate x
    float ty = 2;   // translate y
    float angle = 30;

    float rad = angle * M_PI / 180;

    // 🔹 Step 1: Rotate (around origin)
    float rx1 = x1*cos(rad) - y1*sin(rad);
    float ry1 = x1*sin(rad) + y1*cos(rad);

    float rx2 = x2*cos(rad) - y2*sin(rad);
    float ry2 = x2*sin(rad) + y2*cos(rad);

    // 🔹 Step 2: Translate
    float fx1 = rx1 + tx;
    float fy1 = ry1 + ty;

    float fx2 = rx2 + tx;
    float fy2 = ry2 + ty;

    // Transformed line (thicker)
    glColor3f(0, 0, 0);
    glLineWidth(3.0);

    glBegin(GL_LINES);
        glVertex2f(fx1, fy1);
        glVertex2f(fx2, fy2);
    glEnd();

    glFlush();
}

void init() {
    glClearColor(1, 1, 1, 1);

    glMatrixMode(GL_PROJECTION);
    gluOrtho2D(-1, 10, -1, 10);
}

int main(int argc, char** argv) {
    glutInit(&argc, argv);
    glutInitWindowSize(600, 600);
    glutCreateWindow("Manual Transformation - Line");

    init();
    glutDisplayFunc(display);
    glutMainLoop();

    return 0;
}
