#include <GL/glut.h>
#include <bits/stdc++.h>
using namespace std;

void drawLine(float x1, float y1, float x2, float y2) {
    glBegin(GL_LINES);
    glVertex2f(x1, y1);
    glVertex2f(x2, y2);
    glEnd();
}

void line_reflection() {
    float x1 = 2, y1 = 3;
    float x2 = 6, y2 = 7;

    glColor3f(0, 0, 0);
    drawLine(x1, y1, x2, y2);

    //about x axis
    glColor3f(1, 0, 0);
    drawLine(x1, -y1, x2, -y2);

    //about y axis
    glColor3f(0, 0, 1);
    drawLine(-x1, y1, -x2, y2);
}

void init() {
    glClearColor(1, 1, 1, 1);
    glMatrixMode(GL_PROJECTION);
    glLoadIdentity();
    gluOrtho2D(-10, 10, -10, 10);
}

void display() {
    glClear(GL_COLOR_BUFFER_BIT);

    line_reflection();

    glFlush();
}

int main(int argc, char** argv) {
    glutInit(&argc, argv);
    glutInitDisplayMode(GLUT_SINGLE | GLUT_RGB);
    glutInitWindowSize(500, 500);
    glutCreateWindow("Line Reflection: X-axis then Y-axis");
    init();
    glutDisplayFunc(display);
    glutMainLoop();
    return 0;
}
