#include <GL/glut.h>

int ww = 600, wh = 600;

// We'll use a simple grid to track filled area
int grid[600][600] = {0};

void drawFilledRectangle() {
    // Fill inside area manually using grid
    for (int i = 200; i <= 400; i++) {
        for (int j = 200; j <= 400; j++) {
            grid[i][j] = 1; // mark filled
        }
    }

    // Draw boundary
    glColor3f(0, 0, 0);
    glBegin(GL_LINE_LOOP);
    glVertex2i(200, 200);
    glVertex2i(400, 200);
    glVertex2i(400, 400);
    glVertex2i(200, 400);
    glEnd();

    // Draw filled area
    glColor3f(1, 0, 0); // red fill
    glBegin(GL_POINTS);
    for (int i = 200; i <= 400; i++) {
        for (int j = 200; j <= 400; j++) {
            glVertex2i(i, j);
        }
    }
    glEnd();
}

// Display
void display() {
    glClear(GL_COLOR_BUFFER_BIT);
    glPointSize(2.0);

    drawFilledRectangle();

    glFlush();
}

// Init
void init() {
    glClearColor(1, 1, 1, 1);
    gluOrtho2D(0, ww, 0, wh);
}

// Main
int main(int argc, char** argv) {
    glutInit(&argc, argv);
    glutInitWindowSize(600, 600);
    glutCreateWindow("Filled Rectangle");

    init();
    glutDisplayFunc(display);

    glutMainLoop();
}
