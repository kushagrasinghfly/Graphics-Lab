#include <GL/glut.h>
#include <bits/stdc++.h>
#include <cmath>
using namespace std;

void triangle() {
    int x1 = 0, y1 = 50;
    int x2 = 50, y2 = 50;
    int x3 = 50, y3 = 0;
    
    float angle = 30 * 3.14 / 180.0;
    
    float newX1 = x1*cos(angle) - y1*sin(angle);
    float newY1 = x1*sin(angle) + y1*cos(angle);
    
    float newX2 = x2*cos(angle) - y2*sin(angle);
    float newY2 = x2*sin(angle) + y2*cos(angle);
    
    float newX3 = x3*cos(angle) - y3*sin(angle);
    float newY3 = x3*sin(angle) + y3*cos(angle);
    
    glBegin(GL_LINE_LOOP);
    	glColor3f(1, 1, 1);
    	glVertex2i(newX1, newY1);
    	glVertex2i(newX2, newY2);
    	glVertex2i(newX3, newY3);	
    glEnd();
    
    glBegin(GL_LINE_LOOP);
    	glColor3f(1, 1, 1);
    	glVertex2i(x1, y1);
    	glVertex2i(x2, y2);
    	glVertex2i(x3, y3);	
    glEnd();
    
}

void display() {
    glClear(GL_COLOR_BUFFER_BIT);
    
    triangle();
    glFlush();
}

void init() {
    glClearColor(0, 0, 0, 0);
    glMatrixMode(GL_PROJECTION);
    glLoadIdentity();
    gluOrtho2D(-50, 100, -50, 100);
}


int main(int argc, char** argv) {
    glutInit(&argc, argv);
    glutInitDisplayMode(GLUT_SINGLE | GLUT_RGB);
    glutInitWindowSize(500, 500);
    glutCreateWindow("Triangle Rotation");

    init();
    glutDisplayFunc(display);
    glutMainLoop();
    return 0;
}

