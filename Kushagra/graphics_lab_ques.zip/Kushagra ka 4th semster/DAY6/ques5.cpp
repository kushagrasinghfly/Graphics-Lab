#include <GL/glut.h>
#include <iostream>

float boundaryColor[3] = {0.0, 0.0, 0.0}; 
float fillColor[3] = {1.0, 0.0, 0.0};     

void boundaryFill8(int x, int y, float* fillC, float* boundC) {
    float interiorColor[3];
    glReadPixels(x, y, 1, 1, GL_RGB, GL_FLOAT, interiorColor);

    // Check if current pixel is NOT the boundary and NOT already filled
    if ((interiorColor[0] != boundC[0] || interiorColor[1] != boundC[1] || interiorColor[2] != boundC[2]) &&
        (interiorColor[0] != fillC[0] || interiorColor[1] != fillC[1] || interiorColor[2] != fillC[2])) {
        
        // Pixel ko fill karo
        glColor3fv(fillC);
        glBegin(GL_POINTS);
            glVertex2i(x, y);
        glEnd();
        glFlush();

     
        boundaryFill8(x + 1, y, fillC, boundC);     // Right
        boundaryFill8(x - 1, y, fillC, boundC);     // Left
        boundaryFill8(x, y + 1, fillC, boundC);     // Up
        boundaryFill8(x, y - 1, fillC, boundC);     // Down
        boundaryFill8(x + 1, y + 1, fillC, boundC); // Top-Right
        boundaryFill8(x - 1, y + 1, fillC, boundC); // Top-Left
        boundaryFill8(x + 1, y - 1, fillC, boundC); // Bottom-Right
        boundaryFill8(x - 1, y - 1, fillC, boundC); // Bottom-Left
    }
}

void mouse(int button, int state, int x, int y) {
    if (button == GLUT_LEFT_BUTTON && state == GLUT_DOWN) {
        // OpenGL coordinates y-axis invert hoti hain screen se
        int xi = x;
        int yi = 600 - y;
        boundaryFill8(xi, yi, fillColor, boundaryColor);
    }
}

void display() {
    glClear(GL_COLOR_BUFFER_BIT);

  
    glColor3fv(boundaryColor);
    glLineWidth(2.0);
    glBegin(GL_LINE_LOOP);
        glVertex2i(150, 150);
        glVertex2i(450, 150);
        glVertex2i(450, 450);
        glVertex2i(150, 450);
    glEnd();

    glFlush();
}

void init() {
    glClearColor(1.0, 1.0, 1.0, 1.0); 
    glMatrixMode(GL_PROJECTION);
    gluOrtho2D(0, 600, 0, 600);
}

int main(int argc, char** argv) {
    glutInit(&argc, argv);
    glutInitDisplayMode(GLUT_SINGLE | GLUT_RGB);
    glutInitWindowSize(600, 600);
    glutCreateWindow("Boundary Fill 8-Connected");
    init();
    glutDisplayFunc(display);
    glutMouseFunc(mouse); // Mouse click se fill start hoga
    glutMainLoop();
    return 0;
}
