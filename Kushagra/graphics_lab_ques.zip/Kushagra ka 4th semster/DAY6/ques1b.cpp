#include <GL/glut.h>
#include <bits/stdc++.h>
using namespace std;

void line_reflection(){
    
}

void init() {
    glClearColor(1, 1, 1, 1);
    glMatrixMode(GL_PROJECTION);
    glLoadIdentity();
    gluOrtho2D(-10,10,-10,10);
}

void display() {
    glClear(GL_COLOR_BUFFER_BIT);

    ladder(); 

    glFlush();
}

int main(int argc, char** argv) {
    glutInit(&argc, argv);
    glutInitDisplayMode(GLUT_SINGLE | GLUT_RGB);
    glutInitWindowSize(500, 500);
    glutCreateWindow("A tilted ladder");
    init();
    glutDisplayFunc(display);
    glutMainLoop();
    return 0;
}
