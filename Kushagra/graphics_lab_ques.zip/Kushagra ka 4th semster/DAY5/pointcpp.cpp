#include <graphics.h>
#include <conio.h>

using namespace std;

int main() {
	int gd = DETECT, gm, gd;
	
	initgraph(&gd, &gm, "");
	putpixel(100,200,red);
	getch();
	closegraph();

	return 0;
}
